USE FlexPhone

-- INSERT TO STAFF MASTER TABLE
INSERT INTO Staff VALUES 
('ST001', 'Samuel', 'Samuel@bluejack.com', '1990', 'Male', '+6282279855656', 'Gang Mawar', 5000000),
('ST002', 'Ginna', 'Ginna@sunib.edu', '1991-09-09', 'Female', '+6282272919302', 'Gang Anggrek', 4900000),
('ST003', 'Rudy Hermawan', 'Rudy.Hermawan@bluejack.com', '1985-12-12', 'Male', '+6284545656236', 'Jalan Jenderal Sudirman', 8000000),
('ST004', 'Andi Santoso', 'Andi.Santoso@sunib.edu', '1998-09-12', 'Male', '+6285578956145', 'Kelapa Gading', 7500000),
('ST005', 'Rina', 'Rina@sunib.edu', '1995-11-28', 'Female', '+6285512345698', 'Komplek Durian', 4500000),
('ST006', 'Donny Sitohang', 'DonnyS@bluejack.com', '1990-01-17', 'Male', '+6285545612398', 'Jalan Pisang', 6000000),
('ST007', 'Rubens', 'Rubens.Hughes@sunib.edu', '2000-02-28', 'Male', '+6284475612348', 'Jalan Kapten Patimura', 4500000),
('ST008', 'Andre Budiman', 'Andre.Budiman@bluejack.com', '1999-02-12', 'Male', '+6287798746541', 'Gang Mawar', 8500000),
('ST009', 'Ronaldo Wati', 'Ronaldo.Wati@sunib.edu', '2000-02-20', 'Female', '+6289998746541', 'Jalan Sepak Bola', 4500000),
('ST010', 'Mega', 'Mega@bluejack.com', '1999-01-13', 'Female', '+6285545612316', 'Gang Tengkorak', 3500000)


-- INSERT TO CUSTOMER MASTER TABLE
INSERT INTO Customer VALUES
('CU001', 'Robert Martin' ,'Martin.Robert@bluejack.com', '2002-07-07', 'Male', '+628465659898', 'Jalan Bebek Nomor 10E'),
('CU002', 'Jeremy Jackson' ,'Jeremy.Jackson@bluejack.com', '2003-12-30', 'Male', '+6287595123652', 'Komplek Melati Nomor 4A'),
('CU003', 'Jessica Anderson' ,'Jessica.Anderson@sunib.edu', '2000-07-13', 'Female', '+6282278945612', 'Gang Kucing Nomor 5A'),
('CU004', 'Verawati' ,'Verawati@bluejack.com', '1999-09-23', 'Female', '+628465659898', 'Jalan Bebek Nomor 10D'),
('CU005', 'Marcello Sutanto' ,'M.Sutanto@bluejack.com', '1999-11-11', 'Male', '+6286645612356', 'Jalan Kembar Nomor 7A'),
('CU006', 'Vani Rahma Wati' ,'Vani.Wati@bluejack.com', '2001-12-08', 'Female', '+6287745125623', 'Jalan Kembang Nomor 9B'),
('CU007', 'Valencia' ,'Valencia@sunib.edu', '1999-07-13', 'Female', '+628465659898', 'Jalan Tupperware Nomor 11M'),
('CU008', 'Toni Andika' ,'Toni.Andika@bluejack.com', '1999-01-01', 'Male', '+6287754216532', 'Jalan Mawar Nomor 8N'),
('CU009', 'Giovanni Dio' ,'Giovanni@bluejack.com', '2001-05-21', 'Female', '+6286695863268', 'Jalan Rocket Nomor 2E'),
('CU010', 'Samuel Daniel' ,'Samuel.Niel@sunib.edu', '1999-06-12', 'Male', '+6285465321956', 'Jalan Kopi Nomor 18A')


-- INSERT TO VENDOR MASTER TABLE
INSERT INTO Vendor VALUES
('VE001', 'Sugi Inc', 'SugiInc@sunib.edu', '+6283216549871', 'Jalan Merawak Nomor 13A'),
('VE002', 'Martinus Roberto', 'RobertoMartinus@sunib.edu', '+6287894561230', 'Jalan Serawak Nomor 17A'),
('VE003', 'Denny Eduard', 'Denny@bluejack.com', '+6284512367896', 'Gang Bawang Nomor 12'),
('VE004', 'Roy Wilson', 'Roy.Wilson@sunib.edu', '+6287845693654', 'Jalan Shanghai Nomor 19A'),
('VE005', 'Owen Daniel', 'Daniel.Owen@bluejack.com', '+6281165325421', 'Jalan Taiwan Nomor 17A'),
('VE006', 'Hans Christian', 'Hans.Christian@sunib.edu', '+6289967853452', 'Jalan Pinoh Nomor 2H'),
('VE007', 'Conrad Andersen', 'Conrad.Andersen@bluejack.com', '+6283312569874', 'Jalan Sipirok Nomor 10A'),
('VE008', 'Joko Martin', 'Martin.Joko@bluejack.com', '+6288856451232', 'Jalan Landak Nomor 10'),
('VE009', 'Mars', 'Mars@sunib.edu', '+6288874563219', 'Jalan Dire Nomor 01A'),
('VE010', 'Saturnus', 'Saturnus@sunib.edu', '+6288845612389', 'Jalan Sweet Nomor 01A')


-- INSERT TO PHONE BRAND MASTER TABLE
INSERT INTO PhoneBrand VALUES
('PB001','Xiaomo'),
('PB002','Sumsang'),
('PB003','Moto'),
('PB004','Imoo'),
('PB005','Dunkin'),
('PB006','Donar'),
('PB007','Hauweiwei'),
('PB008','Limo'),
('PB009','Aiphine'),
('PB010','Xibobi')


-- INSERT TO PHONE MASTER TABLE
INSERT INTO Phone VALUES
('PO001','PB002','A1',3000000),
('PO002','PB001','A7',3500000),
('PO003','PB002','GP1',2000000),
('PO004','PB007','Ximi5',1300000),
('PO005','PB006','Daxter',3000000),
('PO006','PB003','Meiyu',1700000),
('PO007','PB004','Maxi',4000000),
('PO008','PB005','Kax',4400000),
('PO009','PB006','Reno',3800000),
('PO010','PB002','Reni',2900000),
('PO011','PB002','Carrot',3000000),
('PO012','PB008','Tarix',1100000),
('PO013','PB009','Tarox',8000000),
('PO014','PB009','M1',8800000),
('PO015','PB010','M25',6700000)


-- INSERT TO PURCHASE TRANSACTION HEADER TABLE
INSERT INTO PurchaseHeader VALUES
('PH001', 'ST001', 'VE001', '2020-08-27'),
('PH002', 'ST001', 'VE002', '2021-08-28'),
('PH003', 'ST002', 'VE002', '2022-12-29'),
('PH004', 'ST003', 'VE004', '2019-10-29'),
('PH005', 'ST004', 'VE005', '2020-07-02'),
('PH006', 'ST003', 'VE006', '2021-06-03'),
('PH007', 'ST005', 'VE007', '2022-11-04'),
('PH008', 'ST006', 'VE006', '2023-02-05'),
('PH009', 'ST006', 'VE003', '2022-03-05'),
('PH010', 'ST007', 'VE003', '2020-04-06'),
('PH011', 'ST008', 'VE010', '2019-07-08'),
('PH012', 'ST008', 'VE009', '2020-10-10'),
('PH013', 'ST004', 'VE008', '2021-11-11'),
('PH014', 'ST009', 'VE001', '2020-09-13'),
('PH015', 'ST005', 'VE003', '2021-12-13'),
('PH016', 'ST009', 'VE002', '2021-03-13'),
('PH017', 'ST010', 'VE010', '2020-05-14'),
('PH018', 'ST010', 'VE009', '2021-04-15'),
('PH019', 'ST001', 'VE007', '2019-09-17'),
('PH020', 'ST005', 'VE004', '2021-07-19')


-- INSERT TO PURCHASE TRANSACTION DETAILS TABLE
INSERT INTO PurchaseDetails VALUES
('PH001','PO001',15),
('PH001','PO002',10),
('PH002','PO004',7),
('PH003','PO003',2),
('PH003','PO010',13),
('PH004','PO012',7),
('PH004','PO007',13),
('PH005','PO009',4),
('PH006','PO011',2),
('PH007','PO006',6),
('PH008','PO001',12),
('PH008','PO015',8),
('PH009','PO013',12),
('PH010','PO014',16),
('PH010','PO003',20),
('PH011','PO005',15),
('PH011','PO002',17),
('PH012','PO015',13),
('PH013','PO014',10),
('PH013','PO002',18),
('PH014','PO001',10),
('PH015','PO006',20),
('PH016','PO008',13),
('PH017','PO007',12),
('PH017','PO009',5),
('PH017','PO004',10),
('PH018','PO005',13),
('PH019','PO012',10),
('PH019','PO013',15),
('PH020','PO014',16),
('PH020','PO002',8)


-- INSERT TO SALES TRANSACTION HEADER TABLE
INSERT INTO SalesHeader VALUES
('SH001', 'ST001', 'CU001', '2021-08-26'),
('SH002', 'ST001', 'CU005', '2019-05-25'),
('SH003', 'ST002', 'CU003', '2020-01-01'),
('SH004', 'ST003', 'CU002', '2021-03-02'),
('SH005', 'ST003', 'CU004', '2020-12-11'),
('SH006', 'ST005', 'CU006', '2020-10-12'),
('SH007', 'ST004', 'CU004', '2021-11-14'),
('SH008', 'ST004', 'CU002', '2021-05-15'),
('SH009', 'ST006', 'CU010', '2019-08-01'),
('SH010', 'ST006', 'CU009', '2019-06-08'),
('SH011', 'ST008', 'CU010', '2021-09-12'),
('SH012', 'ST009', 'CU003', '2020-11-07'),
('SH013', 'ST007', 'CU007', '2021-12-06'),
('SH014', 'ST007', 'CU008', '2021-10-11'),
('SH015', 'ST008', 'CU005', '2019-10-16'),
('SH016', 'ST009', 'CU003', '2020-03-12'),
('SH017', 'ST010', 'CU004', '2021-04-17'),
('SH018', 'ST001', 'CU007', '2020-01-24'),
('SH019', 'ST010', 'CU010', '2021-02-23'),
('SH020', 'ST002', 'CU006', '2020-02-06')


-- INSERT TO SALES TRANSACTION DETAILS TABLE
INSERT INTO SalesDetails VALUES
('SH001','PO001',8),
('SH001','PO003',9),
('SH001','PO010',2),
('SH001','PO011',4),
('SH002','PO002',5),
('SH003','PO006',3),
('SH003','PO007',4),
('SH004','PO005',4),
('SH004','PO001',5),
('SH004','PO011',2),
('SH005','PO012',3),
('SH005','PO013',1),
('SH006','PO015',2),
('SH007','PO006',5),
('SH008','PO004',3),
('SH009','PO003',6),
('SH009','PO001',3),
('SH010','PO010',2),
('SH010','PO009',3),
('SH011','PO007',1),
('SH012','PO008',2),
('SH012','PO006',6),
('SH013','PO012',1),
('SH013','PO014',3),
('SH014','PO015',4),
('SH015','PO010',3),
('SH015','PO012',2),
('SH016','PO003',6),
('SH017','PO008',1),
('SH018','PO005',10),
('SH018','PO002',2),
('SH019','PO001',3),
('SH019','PO003',2),
('SH020','PO005',6)





