USE FlexPhone

--1
SELECT CONCAT('Customer',RIGHT(MC.CustomerID,1)) AS ID, CustomerName, CustomerGender, SUM(PhonePrice * PhoneSalesQty) AS [total amount of spending]
FROM Customer MC
JOIN SalesHeader SH ON MC.CustomerID = SH.CustomerID
JOIN SalesDetails SD ON SH.SalesID = SD.SalesID
JOIN Phone MP ON SD.PhoneID = MP.PhoneID
GROUP BY MC.CustomerID, CustomerName, CustomerGender

--2
SELECT MS.StaffID, LEFT(StaffName,CHARINDEX(' ', StaffName + ' ') - 1) AS [Name], COUNT(CustomerID) AS [Customer Count]
FROM Staff MS
JOIN SalesHeader SH ON MS.StaffID = SH.StaffID
WHERE StaffName LIKE '% %'
GROUP BY MS.StaffID, StaffName

--3
SELECT CONCAT('Customer',RIGHT(MC.CustomerID,1)) AS [Customer ID], CustomerName, PB.PhoneBrandName, SUM(PhonePrice * PhoneSalesQty) AS [Total spending]
FROM Customer MC
JOIN SalesHeader SH ON MC.CustomerID = SH.CustomerID
JOIN SalesDetails SD ON SH.SalesID = SD.SalesID
JOIN Phone MP ON SD.PhoneID = MP.PhoneID
JOIN PhoneBrand PB ON MP.PhoneBrandID = PB.PhoneBrandID
WHERE CustomerName LIKE '% %'
GROUP BY MC.CustomerID, CustomerName, PB.PhoneBrandName
HAVING COUNT(DISTINCT SD.PhoneID) > 3

--4
SELECT MS.StaffID, STUFF(StaffEmail,CHARINDEX('@', StaffEmail), LEN(StaffEmail) - CHARINDEX('@', StaffEmail) + 1, '@Ymail.com') AS [Email], SUM(MP.PhonePrice * SD.PhoneSalesQty) AS [total selling]
FROM Staff MS
JOIN SalesHeader SH ON MS.StaffID = SH.StaffID
JOIN SalesDetails SD ON SH.SalesID = SD.SalesID
JOIN Phone MP ON SD.PhoneID = MP.PhoneID
JOIN PhoneBrand PB ON MP.PhoneBrandID = PB.PhoneBrandID
GROUP BY MS.StaffID, StaffEmail
HAVING COUNT(DISTINCT SD.PhoneID) > 2
ORDER BY StaffID ASC

--5
SELECT StaffEmail, StaffGender, CONVERT(VARCHAR, StaffDateOfBirth, 106) AS [Date Of Birth], CONCAT('Rp.',CAST(StaffSalary AS VARCHAR),',00.') AS [Salary]
FROM Staff, 
(
	SELECT AVG(StaffSalary) AS [Salary]
	FROM Staff
) AS [StaffAverageSalary]
WHERE StaffSalary > StaffAverageSalary.Salary 
AND DATEDIFF(YEAR,StaffDateOfBirth, GETDATE()) > 30

--6 
SELECT MS.StaffID, StaffName, REPLACE(StaffPhone, '+62', '0') AS [StaffPhone], CONCAT('Rp.',CAST(Selling.Total AS VARCHAR),',00.') AS [Total Selling]
FROM Staff MS, 
(
	SELECT SH.StaffID, SUM(PhonePrice * PhoneSalesQty) AS [Total]
	FROM SalesHeader SH 
	JOIN SalesDetails SD ON SH.SalesID = SD.SalesID
	JOIN Phone MP ON SD.PhoneID = MP.PhoneID
	GROUP BY SH.StaffID
) AS [Selling]
WHERE MS.StaffID = Selling.StaffID
AND Selling.Total BETWEEN 10000000 AND 100000000
AND StaffGender = 'Male'

--7
SELECT CONCAT('Staff No',RIGHT(MS.StaffID,1)) AS [Staff No], StaffName, STUFF(StaffEmail,CHARINDEX('@', StaffEmail), LEN(StaffEmail) - CHARINDEX('@', StaffEmail) + 1, '@gmail.com') AS [Email], CONVERT(VARCHAR,StaffDateOfBirth, 103) AS [Date Of Birth], [Customer Count]
FROM Staff MS,
(
	SELECT StaffID, COUNT(CustomerID) AS [Customer Count]
	FROM SalesHeader 
	GROUP BY StaffID
) AS [CustCount],
	(
		SELECT MAX([Customer Count]) AS [Maximum Customer]
		FROM
		(
			SELECT StaffID, COUNT(CustomerID) AS [Customer Count]
			FROM SalesHeader 
			GROUP BY StaffID
		) AS [CustCount]
	) AS [MaxCount]
WHERE MS.StaffID = CustCount.StaffID 
AND CustCount.[Customer Count] = MaxCount.[Maximum Customer]

--8
SELECT [SumQty].PhoneBrandID, [SumQty].PhoneBrandName, [SumQty].CustomerID, [SumQty].CustomerName, STUFF([SumQty].CustomerEmail,CHARINDEX('@', [SumQty].CustomerEmail), LEN([SumQty].CustomerEmail) - CHARINDEX('@', [SumQty].CustomerEmail) + 1, '@Gmail.com') AS [Customer Email], Qty
FROM 
(
	SELECT PB.PhoneBrandID, PB.PhoneBrandName, MC.CustomerID, CustomerName, MC.CustomerEmail,SUM(PhoneSalesQty) AS [Qty]
	FROM Customer MC
	JOIN SalesHeader SH ON MC.CustomerID = SH.CustomerID
	JOIN SalesDetails SD ON SH.SalesID = SD.SalesID
	JOIN Phone MP ON SD.PhoneID = MP.PhoneID
	JOIN PhoneBrand PB ON MP.PhoneBrandID = PB.PhoneBrandID
	GROUP BY PB.PhoneBrandID, PB.PhoneBrandName, MC.CustomerID, CustomerName, MC.CustomerEmail
) AS [SumQty],
(
		SELECT MAX(Qty) AS [Maximum Total], PhoneBrandID
		FROM
		(
			SELECT PB.PhoneBrandID, MC.CustomerID ,SUM(PhoneSalesQty) AS [Qty]
			FROM Customer MC
			JOIN SalesHeader SH ON MC.CustomerID = SH.CustomerID
			JOIN SalesDetails SD ON SH.SalesID = SD.SalesID
			JOIN Phone MP ON SD.PhoneID = MP.PhoneID
			JOIN PhoneBrand PB ON MP.PhoneBrandID = PB.PhoneBrandID
			GROUP BY PB.PhoneBrandID, MC.CustomerID
		) AS [SumQty]
		GROUP BY PhoneBrandID
	) AS [MaxTot]
WHERE MaxTot.PhoneBrandID = SumQty.PhoneBrandID
AND SumQty.Qty = MaxTot.[Maximum Total]
AND CustomerEmail LIKE '%@bluejack.com'
AND CAST(RIGHT(SumQty.CustomerID,3) AS INT) % 2 = 0
ORDER BY SumQty.PhoneBrandID ASC

--9
GO
CREATE VIEW Vendor_Brand_Transaction_View AS
SELECT CONCAT('Vendor',RIGHT(MV.VendorID,1)) AS [VendorID], VendorName, REPLACE(VendorPhone, '+62', '0') AS [PhoneNumber], PB.PhoneBrandName, COUNT(PB.PhoneBrandID) AS [Transaction Count], SUM(MP.PhonePrice * PhonePurchaseQty) AS [Total Transaction]
FROM Vendor MV
JOIN PurchaseHeader PH ON MV.VendorID = PH.VendorID
JOIN PurchaseDetails PD ON PH.PurchaseID = PD.PurchaseID
JOIN Phone MP ON PD.PhoneID = MP.PhoneID
JOIN PhoneBrand PB ON MP.PhoneBrandID = PB.PhoneBrandID
GROUP BY MV.VendorID, VendorName, VendorPhone, PB.PhoneBrandName

--10
GO
CREATE VIEW Staff_Selling_View AS
SELECT MS.StaffID, StaffName, CONCAT(CAST(SUM(PhoneSalesQty) AS VARCHAR), 'pc(s)') AS [Sold Phone Count], CONCAT('Rp.', CAST(SUM(MP.PhonePrice * PhoneSalesQty) AS VARCHAR), ',00') AS [Total Transaction], COUNT(DISTINCT PB.PhoneBrandID) AS [Count Brand]
FROM Staff MS
JOIN SalesHeader SH ON MS.StaffID = SH.StaffID
JOIN SalesDetails SD ON SH.SalesID = SD.SalesID
JOIN Phone MP ON SD.PhoneID = MP.PhoneID
JOIN PhoneBrand PB ON MP.PhoneBrandID = PB.PhoneBrandID
WHERE StaffEmail LIKE '%@bluejack.com'
GROUP BY MS.StaffID, StaffName



